run 'dune build' to build the game (if the project.zip exists after unzip and dune build fails, type rm -f project.zip)
, then run 'dune exec src/terminal.exe' to run the game. There are no any external libraries used.

Reference: I was stuck when implementing game.ml, so I looked at the https://github.com/zbcszr/Mahjong
repo for inspiration. I studied the picture they draw on README and the mli files they wrote, 
and used their logic to simulate a round.
